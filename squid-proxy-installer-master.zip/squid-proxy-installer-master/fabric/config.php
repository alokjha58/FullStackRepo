<?php

$squid_username = "boby";
$squid_password = "superman123";
